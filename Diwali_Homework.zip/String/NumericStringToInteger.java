import java.util.*;
class NumericStringToInteger{
public static void main(String args[]){
String s="67263";
System.out.println(s);
int n=Integer.parseInt(s);
System.out.println("After conversion to integer: "+n);



}





}