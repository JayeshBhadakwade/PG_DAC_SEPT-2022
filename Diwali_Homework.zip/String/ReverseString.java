class ReverseString{
	public static void main(String args[]){
String s="Hello World";
char string[]=s.toCharArray();
System.out.println("String after Reversing:");
for(int i=string.length-1;i>=0;i--){
System.out.print(string[i]);
}

}





}