class SumOfTwoBytes{
public static void main(String args[]){
byte x=10;
byte y=124;

int sum =(int)(x+y);
System.out.println("sum after typecasting in is: "+sum);



}





}