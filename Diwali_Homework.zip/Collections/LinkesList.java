import java.util.*;
class LinkedList{
public static void main(String args[]){
LinkedList ll =new LinkedList();
ll.add(0,1);




}



}