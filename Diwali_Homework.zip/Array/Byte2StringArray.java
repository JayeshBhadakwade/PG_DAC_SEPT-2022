class Byte2StringArray{
public  static void main(String args[]){
byte b[]={65,66,67,68,69};
System.out.println("byte array is:");
for(byte x:b){
	System.out.print(x+" ");
}
System.out.println();
System.out.println("String array is:");
String s =new String(b);
System.out.print(s);




}






}