import java.util.*;
class AscndDescndOrder{

public static void main(String args[]){
int i=0;

Scanner sc=new Scanner(System.in);
System.out.println("Enter no of elements in array");
int n=sc.nextInt();
int arr[]=new int[n];
System.out.println("Enter arary elements in array");
for(i=0;i<n;i++){
arr[i]=sc.nextInt();
//System.out.println(arr[i]+" ");
}

for(i=1;i<n;i++){
if(arr[i-1]>arr[i]){
//System.out.println(");
}
}
else if(arr[i-1]<arr[i])


System.out.println("Ascending order array");
}


}