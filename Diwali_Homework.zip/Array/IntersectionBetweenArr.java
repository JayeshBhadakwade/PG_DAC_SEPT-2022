class IntersectionBetweenArr{
public static void main(String args[]){
int arr[]={1,2,3,4,5,6,7,8,99};
int arr1[]={1,2,3,11,23,45,55,88,99};
int i=0;
System.out.println("Common elements are:");
for(i=0;i<arr.length;i++){
if(arr[i]==arr1[i]){
System.out.print(arr[i]+" ");
}

}

}








}