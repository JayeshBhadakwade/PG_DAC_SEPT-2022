import java.util.*;
class Array2Set{
public static void main(String args[]){
String s[]={"hello","jb"};
System.out.println(s);
Set<String>set=new HashSet<String>();
for(String x:s){
set.add(x);
}




}



}