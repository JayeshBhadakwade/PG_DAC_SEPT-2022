class SeparateZeros{
public static void main(String args[]){
int arr[]={0,1,2,3,0,4,5,0,0};
int arr1[]=new int[9];
int arr2[]=new int[9];
System.out.print("Elements after removing zeros in array ");
for(int i=0;i<arr.length;i++){
if(arr[i]!=0){
arr1[i]=arr[i];
System.out.print(arr1[i]+" ");
}

}



}





}