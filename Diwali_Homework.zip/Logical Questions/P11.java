class P11
{

public static void main(String args[])
	{
	int n=6;
	int i=n,j=0;
	int ch=65;
	int  ch1=65;
	for(i=n;i>=0;i--)
		{
	
		for(j=1;j<=i;j++)
			{
				//++count;
			System.out.print((char)ch+" ");
				
		ch++;
			}
			ch=65;
			
			System.out.println();
		
		}
		for(i=1;i<=n;i++)
		{
	
		for(j=1;j<=i;j++)
			{
				//++count;
			System.out.print((char)ch1+" ");
				
		ch1++;
			}
			ch1=65;
			
			System.out.println();
		
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
	}






}