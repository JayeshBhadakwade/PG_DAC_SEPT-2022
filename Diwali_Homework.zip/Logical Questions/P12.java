class P12
{

public static void main(String args[])
	{
	int n=5;
	int i=0,j=0;
	int ch =65;
	for(i = 0; i <= 5; i++)
		{
		for(j = 5; j > i; j--)
			{
				
			System.out.print(" ");
			
			}
			
			
			
			for (int k = 0; k <= i; k++)
        {
            System.out.print((char) (ch + k) + " ");
        }
		
			System.out.println();
			
			
		
		}
	
		
		
		
	
	}






}