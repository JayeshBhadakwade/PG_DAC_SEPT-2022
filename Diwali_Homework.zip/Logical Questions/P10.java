class P10
{

public static void main(String args[])
	{
	int n=6;
	int i=0,j=0;
	int ch=64;
	for(i=0;i<=n;i++)
		{
	
		for(j=1;j<=i;j++)
			{
				//++count;
			System.out.print((char)ch+" ");
				
		
			}
			ch++;
			
			System.out.println();
		
		}
	
	}






}