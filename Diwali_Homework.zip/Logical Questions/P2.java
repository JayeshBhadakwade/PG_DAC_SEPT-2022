class P2
{

public static void main(String args[])
	{
	int n=5;
	int i=0,j=0;
	int count =1;
	for(i=0;i<=n;i++)
		{
		for(j=0;j<i;j++)
			{
				
			System.out.print(count+" ");
			count ++;
			
			}
			System.out.println();
		
		}
	
	}






}